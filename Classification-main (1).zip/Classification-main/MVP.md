<h1> MVP    </h1>



<h4> Predicting qualified employees for promotion using Classification Models </h4>

<ul>
  <li>MVP Goal : 
    <ul>
      <li>in this project, we want to solve the employee evaluation problem. <br>
how we can develop this model to predict and fit the evaluation target depends on features and get high accuracy through the best models </li>
      
</ul>


![heatmapforclassifi](https://user-images.githubusercontent.com/93095814/146266958-26f4a3b8-3a06-4fe0-9620-a6ba24fbf967.png)
    
    
![download](https://user-images.githubusercontent.com/88141348/146347130-85d74422-4c56-44b8-8d54-993654d3b559.png)
